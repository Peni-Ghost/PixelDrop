module.exports=[71480,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_assets_route_actions_d4eff541.js.map