module.exports=[84351,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_assets_%5Bid%5D_route_actions_096222e1.js.map