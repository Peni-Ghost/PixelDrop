module.exports=[86372,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_config_route_actions_308a9f33.js.map