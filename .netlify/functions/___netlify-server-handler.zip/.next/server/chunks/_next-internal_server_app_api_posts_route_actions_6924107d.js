module.exports=[14394,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_posts_route_actions_6924107d.js.map